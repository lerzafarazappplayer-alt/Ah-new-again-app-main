package com.lerza.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lerza.player.player.AudioPlayerManager

@Composable
fun EqualizerDialog(
    playerManager: AudioPlayerManager,
    onDismiss: () -> Unit
) {
    var bassBoost by remember { mutableFloatStateOf(60f) }
    var band60Hz by remember { mutableFloatStateOf(4f) }
    var band230Hz by remember { mutableFloatStateOf(2f) }
    var band910Hz by remember { mutableFloatStateOf(0f) }
    var band3kHz by remember { mutableFloatStateOf(3f) }
    var band14kHz by remember { mutableFloatStateOf(5f) }
    var isEnabled by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF18181B),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = "Equalizer",
                            tint = Color(0xFF06B6D4),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Equalizer & Bass",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { isEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF06B6D4),
                            checkedTrackColor = Color(0xFF0891B2)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bass Boost Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.horizontalGradient(
                                listOf(Color(0xFF27272A), Color(0xFF1F1F23))
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Bass Boost Engine",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${bassBoost.toInt()}%",
                                color = Color(0xFF06B6D4),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = bassBoost,
                            onValueChange = {
                                bassBoost = it
                                playerManager.setBassBoostStrength((it * 10).toInt().toShort())
                            },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF06B6D4),
                                activeTrackColor = Color(0xFF06B6D4),
                                inactiveTrackColor = Color(0xFF3F3F46)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "5-Band Master Tuner",
                    color = Color(0xFFA1A1AA),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Equalizer Frequencies
                val bands = listOf(
                    "60 Hz" to band60Hz,
                    "230 Hz" to band230Hz,
                    "910 Hz" to band910Hz,
                    "3.6 kHz" to band3kHz,
                    "14 kHz" to band14kHz
                )

                bands.forEachIndexed { index, (label, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = Color(0xFFD4D4D8),
                            fontSize = 12.sp,
                            modifier = Modifier.width(60.dp)
                        )
                        Slider(
                            value = value,
                            onValueChange = { newVal ->
                                when (index) {
                                    0 -> band60Hz = newVal
                                    1 -> band230Hz = newVal
                                    2 -> band910Hz = newVal
                                    3 -> band3kHz = newVal
                                    4 -> band14kHz = newVal
                                }
                                playerManager.setEqualizerBandLevel(
                                    index.toShort(),
                                    (newVal * 100).toInt().toShort()
                                )
                            },
                            valueRange = -10f..10f,
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF06B6D4),
                                activeTrackColor = Color(0xFF06B6D4),
                                inactiveTrackColor = Color(0xFF3F3F46)
                            )
                        )
                        Text(
                            text = "${if (value > 0) "+" else ""}${value.toInt()}dB",
                            color = if (value > 0) Color(0xFF06B6D4) else Color(0xFFA1A1AA),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(42.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF06B6D4)
                    )
                ) {
                    Text(
                        text = "Apply Sound Profile",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
