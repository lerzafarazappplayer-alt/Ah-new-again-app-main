package com.lerza.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.lerza.player.model.Song
import com.lerza.player.model.Video
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MediaRepository {

    suspend fun loadDeviceSongs(context: Context): List<Song> = withContext(Dispatchers.IO) {
        val songsList = mutableListOf<Song>()
        try {
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA
            )

            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"
            val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Unknown Song"
                    val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                    val album = cursor.getString(albumCol) ?: "Unknown Album"
                    val duration = cursor.getLong(durationCol)
                    val path = cursor.getString(dataCol) ?: ""

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    // Extract folder name from path
                    val folderName = if (path.isNotEmpty()) {
                        path.substringBeforeLast('/', "").substringAfterLast('/', "Music")
                    } else "Music"

                    songsList.add(
                        Song(
                            id = id,
                            title = title,
                            artist = if (artist == "<unknown>") "Lerza Artist" else artist,
                            album = album,
                            durationMs = duration,
                            contentUri = contentUri,
                            folderName = folderName,
                            path = path
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // If device has no songs or permission is pending, provide rich preloaded melodious songs
        if (songsList.isEmpty()) {
            songsList.addAll(getDefaultSongs())
        }

        songsList
    }

    suspend fun loadDeviceVideos(context: Context): List<Video> = withContext(Dispatchers.IO) {
        val videosList = mutableListOf<Video>()
        try {
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.RESOLUTION,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.SIZE
            )

            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val resCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.RESOLUTION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Video $id"
                    val duration = cursor.getLong(durationCol)
                    val resolution = cursor.getString(resCol) ?: "1080p HD"
                    val path = cursor.getString(dataCol) ?: ""
                    val size = cursor.getLong(sizeCol)

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    videosList.add(
                        Video(
                            id = id,
                            title = title,
                            durationMs = duration,
                            resolution = resolution,
                            contentUri = contentUri,
                            sizeBytes = size,
                            path = path
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (videosList.isEmpty()) {
            videosList.addAll(getDefaultVideos())
        }

        videosList
    }

    fun getDefaultSongs(): List<Song> {
        return listOf(
            Song(
                id = 101L,
                title = "Lerza Ambient Vibes",
                artist = "Faraz Music Lab",
                album = "Lerza Sessions 2026",
                durationMs = 214000L,
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Kangaroo_MusiQue_-_The_Neverending_Story.mp3"),
                folderName = "Lerza Hits",
                hasLyrics = true
            ),
            Song(
                id = 102L,
                title = "Coke Studio Sufi Echoes",
                artist = "Sufi Ensemble",
                album = "Soulful Pakistan",
                durationMs = 285000L,
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Sevish_-__nbsp_.mp3"),
                folderName = "Sufi Beats",
                hasLyrics = true
            ),
            Song(
                id = 103L,
                title = "Midnight Lo-Fi Chill",
                artist = "Acoustic Sunset",
                album = "Peaceful Beats",
                durationMs = 192000L,
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/codeskulptor-assets/Epoq-Lepidoptera.ogg"),
                folderName = "Lo-Fi",
                hasLyrics = true
            ),
            Song(
                id = 104L,
                title = "Cyber Bass Neon Drive",
                artist = "Synthwave Riders",
                album = "Future Horizon",
                durationMs = 240000L,
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/codeskulptor-demos/riceracer_assets/music/menu.ogg"),
                folderName = "Bass Boost",
                hasLyrics = false
            ),
            Song(
                id = 105L,
                title = "Romantic Ghazal Strings",
                artist = "Ustad Mehdi Raga",
                album = "Classical Gems",
                durationMs = 310000L,
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/codeskulptor-demos/pyman_assets/eatedat.ogg"),
                folderName = "Classical",
                hasLyrics = true
            )
        )
    }

    fun getDefaultVideos(): List<Video> {
        return listOf(
            Video(
                id = 201L,
                title = "Big Buck Bunny 4K Showcase",
                durationMs = 596000L,
                resolution = "1920x1080 Full HD",
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
                sizeBytes = 158000000L
            ),
            Video(
                id = 202L,
                title = "Elephants Dream Cinematic Trailer",
                durationMs = 653000L,
                resolution = "1920x1080 Full HD",
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
                sizeBytes = 142000000L
            ),
            Video(
                id = 203L,
                title = "For Bigger Blazes (HDR Action)",
                durationMs = 15000L,
                resolution = "1280x720 HD",
                contentUri = Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"),
                sizeBytes = 15000000L
            )
        )
    }

    fun getSampleLrcLyrics(): String {
        return """
            [00:01.00]Lerza Player - Soul of Sound
            [00:08.50]Dildaar tere bina jeena nahi
            [00:15.20]Har saans mein teri khushbu hai
            [00:22.80]Dil ki har dharhkan mein tera naam
            [00:30.40]Subah ki pehli kiran jaisa noor
            [00:38.10]Super Volume 300% Boost active
            [00:46.00]Yeh hawayein tera paighaam laati hain
            [00:54.30]Lerza Player - Pure High Fidelity
            [01:05.00]Khamoshiyon mein bhi aik geet hai
            [01:14.20]Tere sang har lamha aabaad hai
            [01:25.00]Sur aur taal ka haseen sangam
            [01:38.00]Forever with Lerza Player Music
        """.trimIndent()
    }
}
