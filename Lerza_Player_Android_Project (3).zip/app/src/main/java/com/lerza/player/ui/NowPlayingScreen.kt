package com.lerza.player.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerza.player.data.MediaRepository
import com.lerza.player.lyrics.SynchronizedLyricsManager
import com.lerza.player.model.LyricLine
import com.lerza.player.model.Song
import com.lerza.player.player.AudioPlayerManager
import kotlinx.coroutines.delay

@Composable
fun NowPlayingScreen(
    song: Song,
    playerManager: AudioPlayerManager,
    onCollapse: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit
) {
    val isPlaying by playerManager.isPlaying.collectAsState()
    val superVolume by playerManager.superVolume.collectAsState()

    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var isDraggingSlider by remember { mutableStateOf(false) }
    var sliderPositionMs by remember { mutableFloatStateOf(0f) }
    var isLyricsMode by remember { mutableStateOf(false) }
    var isFavorite by remember { mutableStateOf(song.isFavorite) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    // Vinyl rotation animation
    val infiniteTransition = rememberInfiniteTransition(label = "VinylRotate")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Lyrics parsing
    val lyricsManager = remember { SynchronizedLyricsManager() }
    val lyricsList = remember(song) {
        lyricsManager.parseLrc(MediaRepository.getSampleLrcLyrics())
    }
    val activeLyricIdx = remember(currentPositionMs, lyricsList) {
        lyricsManager.findActiveLyricIndex(lyricsList, currentPositionMs)
    }
    val lyricsListState = rememberLazyListState()

    // Smooth playback ticker
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            if (!isDraggingSlider) {
                currentPositionMs = playerManager.exoPlayer.currentPosition
            }
            delay(250)
        }
    }

    // Auto-scroll lyrics to active line
    LaunchedEffect(activeLyricIdx) {
        if (isLyricsMode && activeLyricIdx >= 0 && activeLyricIdx < lyricsList.size) {
            lyricsListState.animateScrollToItem((activeLyricIdx - 2).coerceAtLeast(0))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF09090B),
                        Color(0xFF000000)
                    )
                )
            )
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NOW PLAYING",
                        color = Color(0xFF06B6D4),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = song.folderName.ifEmpty { "Lerza Music" },
                        color = Color(0xFFA1A1AA),
                        fontSize = 12.sp
                    )
                }

                IconButton(onClick = { isFavorite = !isFavorite }) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) Color(0xFFEC4899) else Color(0xFFD4D4D8)
                    )
                }
            }

            // Mode Toggle: Disc vs Synchronized Lyrics
            Row(
                modifier = Modifier
                    .background(Color(0xFF18181B), RoundedCornerShape(20.dp))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (!isLyricsMode) Color(0xFF06B6D4) else Color.Transparent)
                        .clickable { isLyricsMode = false }
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Album Art",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!isLyricsMode) Color.Black else Color(0xFFA1A1AA)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isLyricsMode) Color(0xFF06B6D4) else Color.Transparent)
                        .clickable { isLyricsMode = true }
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Lyrics (LRC)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLyricsMode) Color.Black else Color(0xFFA1A1AA)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Center Area: Vinyl Disc OR Lyrics
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                if (!isLyricsMode) {
                    // Rotating Vinyl
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .rotate(if (isPlaying) rotation else 0f)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        Color(0xFF27272A),
                                        Color(0xFF18181B),
                                        Color(0xFF09090B)
                                    )
                                ),
                                shape = CircleShape
                            )
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Inner Vinyl Grooves
                        Box(
                            modifier = Modifier
                                .size(240.dp)
                                .background(Color(0xFF121214), CircleShape)
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // Center Artwork Label
                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
                                        ),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.MusicNote,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }
                    }
                } else {
                    // Synchronized Karaoke Lyrics
                    LazyColumn(
                        state = lyricsListState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        itemsIndexed(lyricsList) { idx, line ->
                            val isActive = idx == activeLyricIdx
                            Text(
                                text = line.text,
                                color = if (isActive) Color(0xFF06B6D4) else Color(0xFF71717A),
                                fontSize = if (isActive) 18.sp else 14.sp,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 10.dp)
                                    .clickable {
                                        playerManager.seekTo(line.timestampMs)
                                        currentPositionMs = line.timestampMs
                                    }
                            )
                        }
                    }
                }
            }

            // Song Title & Artist
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = song.title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = song.artist,
                    fontSize = 14.sp,
                    color = Color(0xFF06B6D4),
                    maxLines = 1
                )
            }

            // 300% Super Volume Slider
            val volumeColor = when {
                superVolume > 200 -> Color(0xFFEF4444)
                superVolume > 100 -> Color(0xFFF59E0B)
                else -> Color(0xFF06B6D4)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF18181B), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.VolumeUp,
                    contentDescription = "Super Volume",
                    tint = volumeColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Slider(
                    value = superVolume.toFloat(),
                    onValueChange = { playerManager.setSuperVolume(it.toInt()) },
                    valueRange = 0f..300f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = volumeColor,
                        activeTrackColor = volumeColor,
                        inactiveTrackColor = Color(0xFF27272A)
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$superVolume%",
                    color = volumeColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Scrubber / Seek Bar
            val totalDuration = if (song.durationMs > 0) song.durationMs else 214000L
            val progressFraction = if (isDraggingSlider) {
                sliderPositionMs / totalDuration.toFloat()
            } else {
                (currentPositionMs.toFloat() / totalDuration.toFloat()).coerceIn(0f, 1f)
            }

            Slider(
                value = progressFraction,
                onValueChange = {
                    isDraggingSlider = true
                    sliderPositionMs = it * totalDuration
                },
                onValueChangeFinished = {
                    isDraggingSlider = false
                    playerManager.seekTo(sliderPositionMs.toLong())
                    currentPositionMs = sliderPositionMs.toLong()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color(0xFF06B6D4),
                    inactiveTrackColor = Color(0xFF27272A)
                )
            )

            // Timestamps
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMs(if (isDraggingSlider) sliderPositionMs.toLong() else currentPositionMs),
                    color = Color(0xFFA1A1AA),
                    fontSize = 12.sp
                )
                Text(
                    text = formatMs(totalDuration),
                    color = Color(0xFFA1A1AA),
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Playback Speed Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                    val isSelected = playbackSpeed == speed
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Color(0xFF06B6D4) else Color(0xFF18181B))
                            .clickable {
                                playbackSpeed = speed
                                playerManager.exoPlayer.setPlaybackSpeed(speed)
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${speed}x",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.Black else Color(0xFFA1A1AA)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Playback Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onOpenEqualizer) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = "Equalizer",
                        tint = Color(0xFF06B6D4),
                        modifier = Modifier.size(26.dp)
                    )
                }

                IconButton(onClick = onPrevious) {
                    Icon(
                        imageVector = Icons.Rounded.SkipPrevious,
                        contentDescription = "Previous",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Large Glowing Play/Pause Button
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
                            ),
                            CircleShape
                        )
                        .clickable { playerManager.togglePlayPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = onNext) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = "Next",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(onClick = { /* Repeat toggle */ }) {
                    Icon(
                        imageVector = Icons.Rounded.Repeat,
                        contentDescription = "Repeat",
                        tint = Color(0xFFA1A1AA),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
