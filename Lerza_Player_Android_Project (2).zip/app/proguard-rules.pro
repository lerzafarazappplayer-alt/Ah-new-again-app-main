# Proguard configuration for Lerza Player

-keep class com.lerza.player.** { *; }
-keepclassmembers class com.lerza.player.** { *; }

# Media3 & ExoPlayer
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Coroutines
-dontwarn kotlinx.coroutines.**
