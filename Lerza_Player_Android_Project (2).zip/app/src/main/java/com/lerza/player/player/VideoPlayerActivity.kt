package com.lerza.player.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class VideoPlayerActivity : ComponentActivity() {

    private lateinit var exoPlayer: ExoPlayer
    private lateinit var playerView: PlayerView

    private var isScreenLocked = false
    private var isAudioOnlyMode = false
    private var isLongPressingSpeed = false

    private lateinit var gestureDetector: GestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on while video is playing
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        exoPlayer = ExoPlayer.Builder(this).build()
        playerView = PlayerView(this).apply {
            player = exoPlayer
            useController = true
        }
        setContentView(playerView)

        setupGestures()

        val videoUriStr = intent.getStringExtra("EXTRA_VIDEO_URI")
        if (!videoUriStr.isNullOrEmpty()) {
            val mediaItem = MediaItem.fromUri(videoUriStr)
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.play()
        }
    }

    private fun setupGestures() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isScreenLocked) return false
                val screenWidth = resources.displayMetrics.widthPixels
                if (e.x > screenWidth / 2) {
                    // Double tap Right: Skip +10s
                    exoPlayer.seekTo(exoPlayer.currentPosition + 10_000)
                    showHUD("Forward +10s")
                } else {
                    // Double tap Left: Skip -10s
                    exoPlayer.seekTo((exoPlayer.currentPosition - 10_000).coerceAtLeast(0))
                    showHUD("Rewind -10s")
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (isScreenLocked) return
                // Long press: 2x Speed
                isLongPressingSpeed = true
                exoPlayer.playbackParameters = PlaybackParameters(2.0f)
                showHUD("2.0x Fast Forward")
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (isScreenLocked || e1 == null) return false
                val screenWidth = resources.displayMetrics.widthPixels
                val deltaY = distanceY / resources.displayMetrics.heightPixels

                if (e1.x > screenWidth / 2) {
                    // Right half vertical swipe: Brightness
                    adjustBrightness(deltaY)
                } else {
                    // Left half vertical swipe: Super Volume (0-300%)
                    adjustVolumeGesture(deltaY)
                }
                return true
            }
        })

        playerView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                if (isLongPressingSpeed) {
                    isLongPressingSpeed = false
                    exoPlayer.playbackParameters = PlaybackParameters(1.0f)
                    showHUD("1.0x Normal Speed")
                }
            }
            gestureDetector.onTouchEvent(event)
            false
        }
    }

    private fun adjustBrightness(delta: Float) {
        val layoutParams = window.attributes
        var currentBrightness = layoutParams.screenBrightness
        if (currentBrightness < 0f) currentBrightness = 0.5f
        val newBrightness = (currentBrightness + delta).coerceIn(0.01f, 1.0f)
        layoutParams.screenBrightness = newBrightness
        window.attributes = layoutParams
        val percent = (newBrightness * 100).toInt()
        showHUD("Brightness: $percent%")
    }

    private fun adjustVolumeGesture(delta: Float) {
        val currentVol = exoPlayer.volume
        val newVol = (currentVol + delta).coerceIn(0.0f, 1.0f)
        exoPlayer.volume = newVol
        val percent = (newVol * 100).toInt()
        showHUD("Volume: $percent%")
    }

    fun enterPictureInPictureModeCustom() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val aspectRatio = Rational(16, 9)
            val pipParams = PictureInPictureParams.Builder()
                .setAspectRatio(aspectRatio)
                .build()
            enterPictureInPictureMode(pipParams)
        }
    }

    fun toggleAudioOnlyMode() {
        isAudioOnlyMode = !isAudioOnlyMode
        if (isAudioOnlyMode) {
            playerView.visibility = View.INVISIBLE
            showHUD("Audio-Only Background Mode ON")
        } else {
            playerView.visibility = View.VISIBLE
            showHUD("Video Mode ON")
        }
    }

    fun toggleScreenLock() {
        isScreenLocked = !isScreenLocked
        playerView.useController = !isScreenLocked
        showHUD(if (isScreenLocked) "Screen Locked 🔒" else "Screen Unlocked 🔓")
    }

    private fun showHUD(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        exoPlayer.release()
    }
}
