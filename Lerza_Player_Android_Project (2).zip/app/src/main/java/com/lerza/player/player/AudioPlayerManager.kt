package com.lerza.player.player

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.lerza.player.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AudioPlayerManager(private val context: Context) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()

    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    // Super Volume percentage: 0% to 300% (100% is standard system max, 101-300% engages LoudnessEnhancer)
    private val _superVolume = MutableStateFlow(100)
    val superVolume: StateFlow<Int> = _superVolume

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    attachAudioEffects(exoPlayer.audioSessionId)
                }
            }
        })
    }

    private fun attachAudioEffects(sessionId: Int) {
        if (sessionId <= 0) return
        try {
            loudnessEnhancer?.release()
            loudnessEnhancer = LoudnessEnhancer(sessionId).apply {
                enabled = true
            }

            equalizer?.release()
            equalizer = Equalizer(0, sessionId).apply {
                enabled = true
            }

            bassBoost?.release()
            bassBoost = BassBoost(0, sessionId).apply {
                enabled = true
            }

            setSuperVolume(_superVolume.value)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Sets Super Volume from 0% up to 300%.
     * 0-100% controls standard ExoPlayer volume.
     * 101-300% engages hardware LoudnessEnhancer with millibels gain (up to 1500mB / +15dB boost).
     */
    fun setSuperVolume(targetPercent: Int) {
        val clamped = targetPercent.coerceIn(0, 300)
        _superVolume.value = clamped

        if (clamped <= 100) {
            exoPlayer.volume = clamped / 100f
            loudnessEnhancer?.setTargetGain(0)
        } else {
            exoPlayer.volume = 1.0f
            val excessPercent = clamped - 100 // 1 to 200
            // Map 1-200% to 100mB - 1800mB gain safely
            val gainMilliBels = (excessPercent * 9).coerceIn(0, 1800)
            try {
                loudnessEnhancer?.setTargetGain(gainMilliBels)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playSong(song: Song) {
        _currentSong.value = song
        val mediaItem = MediaItem.fromUri(song.contentUri)
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
    }

    fun setEqualizerBandLevel(band: Short, levelMilliBels: Short) {
        try {
            equalizer?.setBandLevel(band, levelMilliBels)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBassBoostStrength(strength: Short) {
        try {
            bassBoost?.setStrength(strength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        loudnessEnhancer?.release()
        equalizer?.release()
        bassBoost?.release()
        exoPlayer.release()
    }
}
