package com.lerza.player.lyrics

import com.lerza.player.model.LyricLine
import java.util.regex.Pattern

class SynchronizedLyricsManager {

    private val timePattern = Pattern.compile("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})\\]")

    /**
     * Parses LRC string content into sorted LyricLine list with exact timestamps.
     */
    fun parseLrc(lrcContent: String): List<LyricLine> {
        val lines = mutableListOf<LyricLine>()
        lrcContent.lines().forEach { line ->
            val matcher = timePattern.matcher(line)
            if (matcher.find()) {
                val minutes = matcher.group(1)?.toLongOrNull() ?: 0L
                val seconds = matcher.group(2)?.toLongOrNull() ?: 0L
                val msPart = matcher.group(3) ?: "00"
                val millis = if (msPart.length == 2) msPart.toLong() * 10 else msPart.toLong()
                val totalMs = (minutes * 60 + seconds) * 1000 + millis
                val text = line.substring(matcher.end()).trim()
                if (text.isNotEmpty()) {
                    lines.add(LyricLine(totalMs, text))
                }
            }
        }
        return lines.sortedBy { it.timestampMs }
    }

    /**
     * Returns the index of the currently active lyric line for given playback time in ms.
     */
    fun findActiveLyricIndex(lyrics: List<LyricLine>, currentPositionMs: Long): Int {
        if (lyrics.isEmpty()) return -1
        var activeIdx = -1
        for (i in lyrics.indices) {
            if (currentPositionMs >= lyrics[i].timestampMs) {
                activeIdx = i
            } else {
                break
            }
        }
        return activeIdx
    }
}
