package com.lerza.player.vault

import android.content.Context
import android.content.SharedPreferences
import com.lerza.player.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VaultManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("lerza_vault_prefs", Context.MODE_PRIVATE)

    fun hasPinSet(): Boolean {
        return prefs.contains("VAULT_PIN")
    }

    fun setPin(pin: String): Boolean {
        if (pin.length < 4) return false
        prefs.edit().putString("VAULT_PIN", pin).apply()
        return true
    }

    fun verifyPin(pin: String): Boolean {
        val savedPin = prefs.getString("VAULT_PIN", null) ?: return false
        return savedPin == pin
    }

    /**
     * Smoothly checks whether a song path should be auto-hidden into vault
     * (WhatsApp Voice notes, call recordings, telegram voice memos).
     */
    fun shouldAutoQuarantine(song: Song): Boolean {
        val lower = song.path.lowercase()
        return lower.contains("whatsapp voice") ||
               lower.contains("whatsapp/media/whatsapp audio") ||
               lower.contains("call_recording") ||
               lower.contains("call recording") ||
               lower.contains("sound_recorder")
    }

    suspend fun filterSafeSongs(allSongs: List<Song>): List<Song> = withContext(Dispatchers.Default) {
        val hiddenIds = prefs.getStringSet("MANUAL_HIDDEN_IDS", emptySet()) ?: emptySet()
        allSongs.filter { song ->
            !shouldAutoQuarantine(song) && !hiddenIds.contains(song.id.toString())
        }
    }
}
