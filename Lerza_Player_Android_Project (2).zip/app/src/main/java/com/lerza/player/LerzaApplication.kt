package com.lerza.player

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class LerzaApplication : Application() {
    companion object {
        const val CHANNEL_ID = "lerza_playback_channel"
        lateinit var instance: LerzaApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lerza Player Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Media playback controls and album artwork"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
