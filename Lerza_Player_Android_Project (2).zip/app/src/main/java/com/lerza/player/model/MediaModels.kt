package com.lerza.player.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val contentUri: Uri,
    val albumArtUri: Uri? = null,
    val folderName: String = "",
    val path: String = "",
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayedTimestamp: Long = 0,
    val hasLyrics: Boolean = false,
    val isHiddenInVault: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedTimestamp: Long = 0
)

data class Video(
    val id: Long,
    val title: String,
    val durationMs: Long,
    val resolution: String,
    val contentUri: Uri,
    val thumbnailUri: Uri? = null,
    val sizeBytes: Long = 0,
    val path: String = "",
    val isHiddenInVault: Boolean = false
)

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long>,
    val coverUri: Uri? = null,
    val isSmartPlaylist: Boolean = false
)

data class LyricLine(
    val timestampMs: Long,
    val text: String,
    var translatedUrdu: String = "",
    var translatedEnglish: String = ""
)
