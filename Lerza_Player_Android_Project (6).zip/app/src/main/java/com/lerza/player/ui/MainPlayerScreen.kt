package com.lerza.player.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.lerza.player.R
import com.lerza.player.data.MediaRepository
import com.lerza.player.model.Song
import com.lerza.player.model.Video
import com.lerza.player.player.AudioPlayerManager
import com.lerza.player.player.VideoPlayerActivity
import kotlinx.coroutines.launch

@Composable
fun MainPlayerScreen(
    playerManager: AudioPlayerManager
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var selectedTab by remember { mutableIntStateOf(1) } // 0: Videos, 1: Songs (Default active as in screenshot), 2: Playlists, 3: Folders

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()

    var isNowPlayingOpen by remember { mutableStateOf(false) }
    var isEqualizerOpen by remember { mutableStateOf(false) }
    var isSettingsOpen by remember { mutableStateOf(false) }
    var isVaultOpen by remember { mutableStateOf(false) }
    var isSearchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var sortMethod by remember { mutableStateOf("Date Added") }

    // Theme Customization State (Matching Lerza Purple screenshot)
    var isDarkMode by remember { mutableStateOf(false) } // Default light lavender as in user screenshot
    var primaryColor by remember { mutableStateOf(Color(0xFF8B5CF6)) } // Lerza Purple
    var songTextScale by remember { mutableFloatStateOf(1.20f) } // Comfortable (120%)
    var wallpaperOpacity by remember { mutableFloatStateOf(0.75f) }

    // Colors based on Light/Dark mode
    val backgroundColor = if (isDarkMode) Color(0xFF09090B) else Color(0xFFF7F2FA)
    val cardColor = if (isDarkMode) Color(0xFF18181B) else Color(0xFFFFFFFF)
    val textPrimary = if (isDarkMode) Color.White else Color(0xFF18181B)
    val textSecondary = if (isDarkMode) Color(0xFFA1A1AA) else Color(0xFF71717A)
    val tabInactiveBg = if (isDarkMode) Color(0xFF27272A) else Color(0xFFEDE7F6)

    // Load initial songs & videos
    LaunchedEffect(Unit) {
        val loadedSongs = MediaRepository.loadDeviceSongs(context)
        val loadedVideos = MediaRepository.loadDeviceVideos(context)
        songs = loadedSongs
        videos = loadedVideos
        if (loadedSongs.isNotEmpty() && currentSong == null) {
            playerManager.playSong(loadedSongs[0])
            playerManager.exoPlayer.pause()
        }
    }

    val filteredSongs = remember(songs, searchQuery) {
        if (searchQuery.isBlank()) songs
        else songs.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
            it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        containerColor = backgroundColor,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(backgroundColor)
                    .padding(top = 10.dp, start = 16.dp, end = 16.dp, bottom = 4.dp)
            ) {
                // Header (Matching Screenshot_20261108-111414_Lerza Player.png)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Penguin Logo + LERZA PLAYER + PRO
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { isSettingsOpen = true }
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_logo),
                            contentDescription = "Lerza Logo",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "LERZA PLAYER",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = textPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(primaryColor, RoundedCornerShape(10.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "PRO",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }

                    // Top Action Icons
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { isSearchOpen = true }) {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = textPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        IconButton(onClick = { isVaultOpen = true }) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = "Private Wallet",
                                tint = textPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        IconButton(onClick = { isEqualizerOpen = true }) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = "Equalizer",
                                tint = primaryColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        IconButton(onClick = { isSettingsOpen = true }) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = "Settings",
                                tint = textPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Navigation Tabs (Pill Style as in screenshots)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val tabItems = listOf(
                        0 to ("📹 Videos"),
                        1 to ("Songs"),
                        2 to ("Playlists"),
                        3 to ("📁 Folders")
                    )

                    tabItems.forEach { (index, label) ->
                        val isActive = selectedTab == index
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isActive) primaryColor else tabInactiveBg)
                                .clickable { selectedTab = index }
                                .padding(horizontal = 16.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = label,
                                color = if (isActive) Color.White else textSecondary,
                                fontSize = 13.sp,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            // Persistent Bottom Mini Player (Matching Lark screenshot)
            if (currentSong != null) {
                Surface(
                    color = cardColor,
                    shadowElevation = 8.dp,
                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isNowPlayingOpen = true }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Artwork
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFEDE7F6)),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_logo),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentSong?.title ?: "",
                                color = textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = currentSong?.artist ?: "",
                                color = textSecondary,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }

                        IconButton(onClick = { playerManager.togglePlayPause() }) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = primaryColor,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        IconButton(onClick = {
                            val idx = songs.indexOfFirst { it.id == currentSong?.id }
                            if (idx != -1 && songs.isNotEmpty()) {
                                playerManager.playSong(songs[(idx + 1) % songs.size])
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Rounded.SkipNext,
                                contentDescription = "Next",
                                tint = textPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                // 0: Videos Tab (2-Column Grid as in Screenshot_20261108-111416_Lerza Player.png)
                0 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp)
                    ) {
                        // Subheader: "X Videos Available", Scan & Sort
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${videos.size} Videos Available",
                                color = textSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(cardColor)
                                        .clickable {
                                            coroutineScope.launch {
                                                videos = MediaRepository.loadDeviceVideos(context)
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = null,
                                            tint = primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Scan",
                                            color = textPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Rounded.FilterList,
                                    contentDescription = "Sort",
                                    tint = textPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // 2-Column Grid
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(videos) { video ->
                                Column(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(cardColor)
                                        .clickable {
                                            val intent = Intent(context, VideoPlayerActivity::class.java).apply {
                                                putExtra("EXTRA_VIDEO_URI", video.contentUri.toString())
                                            }
                                            context.startActivity(intent)
                                        }
                                        .padding(8.dp)
                                ) {
                                    // Thumbnail with HD badge and duration
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(105.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFF27272A))
                                    ) {
                                        // HD badge top-left
                                        Box(
                                            modifier = Modifier
                                                .padding(6.dp)
                                                .background(Color(0xFF06B6D4), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                                .align(Alignment.TopStart)
                                        ) {
                                            Text(
                                                text = "HD",
                                                color = Color.Black,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }

                                        // Duration badge bottom-right
                                        Box(
                                            modifier = Modifier
                                                .padding(6.dp)
                                                .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 5.dp, vertical = 2.dp)
                                                .align(Alignment.BottomEnd)
                                        ) {
                                            Text(
                                                text = formatDuration(video.durationMs),
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Title + 3-dots
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = video.title,
                                            color = textPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(
                                            imageVector = Icons.Rounded.MoreVert,
                                            contentDescription = null,
                                            tint = textSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    Text(
                                        text = if (video.path.isNotEmpty()) video.path.substringBeforeLast('/', "").substringAfterLast('/', "Camera") else "Camera",
                                        color = textSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // 1: Songs Tab (Contiguous List as in Screenshot_20261108-111414_Lerza Player.png)
                1 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp)
                    ) {
                        // Subheader: "356 Songs Available" and "Sort: Date Added v"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${filteredSongs.size} Songs Available",
                                color = textSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(cardColor)
                                    .clickable { /* Toggle sort */ }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.FilterList,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Sort: $sortMethod ⌄",
                                        color = textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            itemsIndexed(filteredSongs) { _, song ->
                                val isCurrent = song.id == currentSong?.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isCurrent) primaryColor.copy(alpha = 0.12f) else cardColor)
                                        .clickable { playerManager.playSong(song) }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Album Art Thumbnail
                                    Box(
                                        modifier = Modifier
                                            .size((48 * songTextScale).dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFFEDE7F6)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.ic_logo),
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    // Song metadata
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = song.title,
                                            color = if (isCurrent) primaryColor else textPrimary,
                                            fontSize = (14 * songTextScale).sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            // LYRICS Badge
                                            if (song.hasLyrics) {
                                                Box(
                                                    modifier = Modifier
                                                        .background(
                                                            primaryColor.copy(alpha = 0.15f),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(
                                                        text = "LYRICS",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = primaryColor
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                            }

                                            Text(
                                                text = song.artist,
                                                color = textSecondary,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = formatDuration(song.durationMs),
                                                color = textSecondary,
                                                fontSize = 11.sp
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            // M4A / MP3 format badge
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        Color(0xFFE2E8F0),
                                                        RoundedCornerShape(3.dp)
                                                    )
                                                    .padding(horizontal = 3.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "M4A",
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF64748B)
                                                )
                                            }
                                        }
                                    }

                                    // Heart Favorite
                                    IconButton(onClick = { /* Toggle favorite */ }) {
                                        Icon(
                                            imageVector = Icons.Rounded.FavoriteBorder,
                                            contentDescription = "Favorite",
                                            tint = textSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    // 3-dots Menu
                                    IconButton(onClick = { /* Menu */ }) {
                                        Icon(
                                            imageVector = Icons.Rounded.MoreVert,
                                            contentDescription = "Options",
                                            tint = textSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 2: Playlists Tab (Matching Screenshot_20261108-111420_Lerza Player.png)
                2 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // + Add New Card
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(cardColor)
                                    .border(1.dp, primaryColor.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                                    .clickable { /* Add playlist */ }
                                    .padding(vertical = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Rounded.Add,
                                        contentDescription = "Add",
                                        tint = primaryColor,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Add new",
                                        color = textPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Liked songs (Red square)
                        item {
                            PlaylistItemCard(
                                title = "Liked songs",
                                subtitle = "Tap to open and play tracks",
                                countText = "No songs yet",
                                iconBg = Color(0xFFE11D48),
                                icon = Icons.Rounded.Favorite,
                                cardBg = cardColor,
                                textPrimary = textPrimary,
                                textSecondary = textSecondary
                            )
                        }

                        // Recently played
                        item {
                            PlaylistItemCard(
                                title = "Recently played",
                                subtitle = "♬ Jani Door Gaye\n♬ Tum Ek Gorakh Dhanda Ho",
                                countText = "20",
                                iconBg = Color(0xFF7C3AED),
                                icon = Icons.Rounded.History,
                                cardBg = cardColor,
                                textPrimary = textPrimary,
                                textSecondary = textSecondary
                            )
                        }

                        // Most played
                        item {
                            PlaylistItemCard(
                                title = "Most played",
                                subtitle = "♬ Karbala waqia\n♬ Tasweer-E-Saeed",
                                countText = "15",
                                iconBg = Color(0xFFEA580C),
                                icon = Icons.Rounded.Star,
                                cardBg = cardColor,
                                textPrimary = textPrimary,
                                textSecondary = textSecondary
                            )
                        }

                        // With Lyrics
                        item {
                            PlaylistItemCard(
                                title = "With Lyrics",
                                subtitle = "♬ Jani Door Gaye\n♬ Tum Ek Gorakh Dhanda Ho",
                                countText = "356",
                                iconBg = Color(0xFF0D9488),
                                icon = Icons.Rounded.Description,
                                cardBg = cardColor,
                                textPrimary = textPrimary,
                                textSecondary = textSecondary
                            )
                        }

                        // Section Header
                        item {
                            Text(
                                text = "SMART AUTO PLAYLISTS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = primaryColor,
                                letterSpacing = 1.sp,
                                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                            )
                        }

                        // Sad Songs Special
                        item {
                            PlaylistItemCard(
                                title = "Sad Songs Special",
                                subtitle = "♬ Phir Chala • Bollywood Romantic\n♬ Tu Hi Haqeeqat Lo-fi",
                                countText = "63",
                                iconBg = Color(0xFF4F46E5),
                                icon = Icons.Rounded.MusicNote,
                                cardBg = cardColor,
                                textPrimary = textPrimary,
                                textSecondary = textSecondary
                            )
                        }

                        // Punjabi Hits
                        item {
                            PlaylistItemCard(
                                title = "Punjabi Hits",
                                subtitle = "♬ Trump • Cheema Y",
                                countText = "78",
                                iconBg = Color(0xFFD97706),
                                icon = Icons.Rounded.Headset,
                                cardBg = cardColor,
                                textPrimary = textPrimary,
                                textSecondary = textSecondary
                            )
                        }
                    }
                }

                // 3: Folders Tab (Matching Screenshot_20261108-111425_Lerza Player.png)
                3 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        Text(
                            text = "Internal storage (${songs.size} total tracks)",
                            color = textSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        val folderItems = listOf(
                            "SHAREit" to 265,
                            "SnapTube_Audio" to 56,
                            "download" to 31,
                            "SnapTube Audio" to 4
                        )

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(folderItems) { (fName, fCount) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(cardColor)
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFFE0F2FE)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Folder,
                                            contentDescription = null,
                                            tint = Color(0xFF0284C7),
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(14.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = fName,
                                            color = textPrimary,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "♬ Dil_Laga_Liya_Maine...\n♬ Jani Door Gaye",
                                            color = textSecondary,
                                            fontSize = 11.sp,
                                            maxLines = 2
                                        )
                                    }

                                    Text(
                                        text = "$fCount",
                                        color = textSecondary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Now Playing Fullscreen Screen
    if (isNowPlayingOpen && currentSong != null) {
        Dialog(onDismissRequest = { isNowPlayingOpen = false }) {
            Box(modifier = Modifier.fillMaxSize()) {
                NowPlayingScreen(
                    song = currentSong!!,
                    playerManager = playerManager,
                    onCollapse = { isNowPlayingOpen = false },
                    onOpenEqualizer = { isEqualizerOpen = true },
                    onPrevious = {
                        val currentIdx = songs.indexOfFirst { it.id == currentSong?.id }
                        if (currentIdx > 0) {
                            playerManager.playSong(songs[currentIdx - 1])
                        }
                    },
                    onNext = {
                        val currentIdx = songs.indexOfFirst { it.id == currentSong?.id }
                        if (currentIdx != -1 && songs.isNotEmpty()) {
                            val nextIdx = (currentIdx + 1) % songs.size
                            playerManager.playSong(songs[nextIdx])
                        }
                    }
                )
            }
        }
    }

    // Sound Equalizer Dialog (10-Band Studio DSP Engine)
    if (isEqualizerOpen) {
        EqualizerDialog(
            playerManager = playerManager,
            onDismiss = { isEqualizerOpen = false }
        )
    }

    // Settings & Theme Customization Page
    if (isSettingsOpen) {
        Dialog(onDismissRequest = { isSettingsOpen = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = cardColor,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Theme & Customization",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                        IconButton(onClick = { isSettingsOpen = false }) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = textPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Mode Switcher (Dark, Light, System)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(tabInactiveBg, RoundedCornerShape(20.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isDarkMode) primaryColor else Color.Transparent)
                                .clickable { isDarkMode = true }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🌙 Dark",
                                color = if (isDarkMode) Color.White else textSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (!isDarkMode) primaryColor else Color.Transparent)
                                .clickable { isDarkMode = false }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "☀️ Light",
                                color = if (!isDarkMode) Color.White else textSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Accent Colors",
                        color = textSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // 8 Colors Swatches as in Screenshot
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val swatches = listOf(
                            Color(0xFF10B981), // Mint Green
                            Color(0xFFF43F5E), // Coral Pink
                            Color(0xFF22C55E), // Green
                            Color(0xFF38BDF8), // Blue
                            Color(0xFF8B5CF6), // Lerza Purple
                            Color(0xFFF97316), // Orange
                            Color(0xFFEF4444), // Red
                            Color(0xFFEC4899)  // Magenta
                        )
                        swatches.forEach { col ->
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(col)
                                    .clickable { primaryColor = col },
                                contentAlignment = Alignment.Center
                            ) {
                                if (primaryColor == col) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Song Size & Thickness: ${(songTextScale * 100).toInt()}%",
                        color = textSecondary,
                        fontSize = 12.sp
                    )
                    Slider(
                        value = songTextScale,
                        onValueChange = { songTextScale = it },
                        valueRange = 0.9f..1.4f,
                        colors = SliderDefaults.colors(
                            thumbColor = primaryColor,
                            activeTrackColor = primaryColor
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { isSettingsOpen = false },
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Apply & Save", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Private Wallet / Secret Vault Dialog (Matching Screenshot_20261108-111544_Lerza Player.png)
    if (isVaultOpen) {
        Dialog(onDismissRequest = { isVaultOpen = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = cardColor,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { isVaultOpen = false }) {
                                Icon(imageVector = Icons.Rounded.Close, contentDescription = "Back", tint = textPrimary)
                            }
                            Text(
                                text = "Private Wallet",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary
                            )
                        }

                        Row {
                            Icon(imageVector = Icons.Rounded.Cloud, contentDescription = null, tint = primaryColor)
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(imageVector = Icons.Rounded.Lock, contentDescription = null, tint = Color(0xFFEF4444))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Audio vs Video Switcher
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(tabInactiveBg, RoundedCornerShape(20.dp))
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(primaryColor)
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🎧 Audio", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📹 Video", color = textSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Pills: All, WhatsApp Audio, Call Recordings
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("All", "WhatsApp Audio", "Call Recordings").forEachIndexed { idx, filterLabel ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (idx == 0) primaryColor else tabInactiveBg)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = filterLabel,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (idx == 0) Color.White else textSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))

                    // Empty state
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Folder,
                            contentDescription = null,
                            tint = textSecondary,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No hidden files in this section",
                            color = textSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { /* Auto-scan */ },
                            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(imageVector = Icons.Rounded.Refresh, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Auto-Scan Call & WhatsApp Audios",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }

    // Search Page with YouTube (Matching Screenshot_20261108-111451_Lerza Player.png)
    if (isSearchOpen) {
        Dialog(onDismissRequest = { isSearchOpen = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = cardColor,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search music and YouTube...") },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = {
                            Icon(imageVector = Icons.Rounded.Search, contentDescription = null, tint = primaryColor)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(imageVector = Icons.Rounded.Close, contentDescription = "Clear", tint = textPrimary)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = primaryColor,
                            focusedTextColor = textPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Chips: All, Songs, Artists, Videos, Sad, Punjabi
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("All", "Songs", "Artists", "Videos", "Sad", "Punjabi").forEachIndexed { idx, chip ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (idx == 0) primaryColor else tabInactiveBg)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = chip,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (idx == 0) Color.White else textSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "History",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("tututu", "Sad mood", "Arjit Singh", "new release").forEach { h ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, primaryColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = h, fontSize = 11.sp, color = textPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { isSearchOpen = false },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Show Matching Tracks", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistItemCard(
    title: String,
    subtitle: String,
    countText: String,
    iconBg: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    cardBg: Color,
    textPrimary: Color,
    textSecondary: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(cardBg)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = textPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = textSecondary,
                fontSize = 11.sp,
                maxLines = 2
            )
        }

        Text(
            text = countText,
            color = textSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
