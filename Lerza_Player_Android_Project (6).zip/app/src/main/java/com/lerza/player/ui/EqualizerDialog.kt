package com.lerza.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lerza.player.player.AudioPlayerManager

@Composable
fun EqualizerDialog(
    playerManager: AudioPlayerManager,
    onDismiss: () -> Unit
) {
    var isEnabled by remember { mutableStateOf(true) }
    var selectedBooster by remember { mutableStateOf("Bass Booster") }
    var selectedPreset by remember { mutableStateOf("Jazz") }

    // 10-Band EQ frequencies from screenshot: 31, 63, 125, 250, 500, 1K, 2K, 4K, 8K, 16K
    var bandLevels by remember {
        mutableStateOf(
            listOf(
                3f, 3f, 2f, 0f, -1f, -1f, 0f, 2f, 3f, 4f
            )
        )
    }

    val frequencies = listOf("31", "63", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF13111C),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Top Header (Matching Screenshot_20261108-111530_Lerza Player.png)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF2E1065)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = Color(0xFFA855F7),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Sound Equalizer",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "10-Band Studio DSP Engine Active",
                                fontSize = 11.sp,
                                color = Color(0xFFA855F7)
                            )
                        }
                    }

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { isEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF8B5CF6)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 10-Band Studio EQ Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF1C1929))
                        .border(1.dp, Color(0xFF3B2865), RoundedCornerShape(18.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "+10 dB", color = Color(0xFF71717A), fontSize = 10.sp)
                            Text(
                                text = "Studio EQ",
                                color = Color(0xFFA855F7),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = "-10 dB", color = Color(0xFF71717A), fontSize = 10.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // dB readouts row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            bandLevels.forEach { lvl ->
                                Text(
                                    text = if (lvl > 0) "+${lvl.toInt()}" else "${lvl.toInt()}",
                                    color = if (lvl > 0) Color(0xFFA855F7) else Color(0xFFA1A1AA),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(22.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Sliders columns
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            bandLevels.forEachIndexed { idx, value ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.width(22.dp)
                                ) {
                                    // Visual Slider Bar
                                    Box(
                                        modifier = Modifier
                                            .width(5.dp)
                                            .height(80.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color(0xFF27272A))
                                    ) {
                                        val fillFraction = ((value + 10f) / 20f).coerceIn(0f, 1f)
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .fillMaxHeight(fillFraction)
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(Color(0xFF8B5CF6))
                                                .align(Alignment.BottomCenter)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = frequencies[idx],
                                        color = Color(0xFF71717A),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ACOUSTIC BOOSTERS (2x2 Grid)
                Text(
                    text = "⚡ ACOUSTIC BOOSTERS",
                    color = Color(0xFFA855F7),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val boosters = listOf("Custom", "Bass Booster", "Vocal Booster", "Treble Booster")
                    boosters.chunked(2).forEach { colPair ->
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            colPair.forEach { bName ->
                                val isSelected = selectedBooster == bName
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) Color(0xFF2E1065) else Color(0xFF1C1929))
                                        .border(
                                            1.dp,
                                            if (isSelected) Color(0xFF8B5CF6) else Color(0xFF27272A),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable { selectedBooster = bName }
                                        .padding(vertical = 10.dp, horizontal = 12.dp)
                                ) {
                                    Text(
                                        text = bName,
                                        color = if (isSelected) Color.White else Color(0xFFD4D4D8),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // GENRE PRESETS
                Text(
                    text = "🎵 GENRE PRESETS",
                    color = Color(0xFFA855F7),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                val presets = listOf("Normal", "Pop", "HipHop", "Rock", "Electronic", "Heavy Metal", "R&B", "Folk", "Dance", "Jazz", "Classic", "Latin")

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(presets) { pName ->
                        val isSelected = selectedPreset == pName
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF8B5CF6) else Color(0xFF1C1929))
                                .clickable { selectedPreset = pName }
                                .padding(vertical = 9.dp, horizontal = 12.dp)
                        ) {
                            Text(
                                text = pName,
                                color = if (isSelected) Color.White else Color(0xFFD4D4D8),
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6))
                ) {
                    Text("Apply & Close", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
